/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["index.html","views/*.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

